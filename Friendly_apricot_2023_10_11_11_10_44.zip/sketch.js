let x, y; // Position of the ellipse

function setup() {
  createCanvas(400, 400);
  x = width / 2; // Initialize x at the center of the canvas
  y = height / 2; // Initialize y at the center of the canvas
}

function draw() {
  background(220); // Set the background color

  // Draw the ellipse at the current position
  ellipse(x, y, 50, 50);

  // Check for arrow key presses and update the position accordingly
  if (keyIsDown(LEFT_ARROW)) {
    x -= 5;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    x += 5;
  }
  if (keyIsDown(UP_ARROW)) {
    y -= 5;
  }
  if (keyIsDown(DOWN_ARROW)) {
    y += 5;
  }
}
